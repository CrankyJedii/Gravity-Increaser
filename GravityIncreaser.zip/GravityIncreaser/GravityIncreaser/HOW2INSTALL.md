1. Extract .zip file via 7zip or Winrar.
2. Drag contents of `GameData` Folder into `Kerbal Space Program/Gamedata` directory.
3. Run KSP!