Current GI Version (Gravity Increaser) = 0.01
Current KSP Version = 1.11.2

Copyright = CrankyJedi
